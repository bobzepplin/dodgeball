$(function() {
	$("#ccm-page-edit-nav-multilingual").dialog();
});