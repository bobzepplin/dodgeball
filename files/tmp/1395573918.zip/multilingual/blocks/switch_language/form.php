<fieldset class="form-stacked" style="padding-top: 20px;">
<div class=" control-group clearfix">
	<?php  echo $form->label('label', t('Label'))?>
	<div class="input">
		<?php  echo $form->text('label', $label)?>
	</div>
</div>
</fieldset>